device driver name  : /dev/dev_driver
device major number : 242

