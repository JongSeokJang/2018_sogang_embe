gcc -fPIC -I /usr/lib/jvm/java-6-oracle/include -I /usr/lib/jvm/java-6-oracle/include/linux -shared -m64 -o libhellojni.so hellojni.c

