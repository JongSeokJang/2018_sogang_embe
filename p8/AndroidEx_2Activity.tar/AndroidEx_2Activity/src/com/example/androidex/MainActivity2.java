package com.example.androidex;

import com.example.androidex.R;

import android.app.Activity;
import android.os.Bundle;



public class MainActivity2 extends Activity{
		@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main2);
	}

}
