package com.example.androidex;

import com.example.androidex.R;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;



public class MainActivity extends Activity{
	
	LinearLayout linear;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		linear = (LinearLayout)findViewById(R.id.container);
	}

}
