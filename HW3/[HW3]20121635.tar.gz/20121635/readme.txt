driver name : /dev/stopwatch
major number : 242
